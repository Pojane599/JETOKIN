import 'package:flutter/material.dart';

class BaseUrlProvider with ChangeNotifier {
  String _baseUrl = "http://192.168.95.117:5012"; // Localhost
  //String _baseUrl = "https://1c83-140-213-163-230.ngrok-free.app";
  //String _baseUrl = "http://192.168.1.9:5012"; //Afra

  String get baseUrl => _baseUrl;

  set baseUrl(String newBaseUrl) {
    if (_baseUrl != newBaseUrl) {
      // Tambahkan pengecekan jika nilai baseUrl berubah
      _baseUrl = newBaseUrl;
      notifyListeners();
    }
  }
}
