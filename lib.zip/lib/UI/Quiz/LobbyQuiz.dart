import 'package:flutter/material.dart';
import 'package:jetokin/UI/Quiz/QuizScreen.dart';

class QuizWelcomeScreen extends StatelessWidget {
  final Map<String, dynamic> userData; // Tambahkan parameter userData

  const QuizWelcomeScreen({Key? key, required this.userData}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    print("User Data in QuizWelcomeScreen: $userData"); // Debug log
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.redAccent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 20.0),
              child: Image.asset(
                'assets/img/Logo Quiz.png',
                height: 150,
              ),
            ),
            const Text(
              'Selamat Datang Di Quis Seru!',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            const Text(
              'Ayo, Jelajahi Pertanyaan Menantang\n dan Raih Skor Tertinggi!',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF9E1B1B),
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                // Navigasi ke QuizScreen dan bawa data user
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => QuizScreen(userData: userData),
                  ),
                );
              },
              child: const Text(
                'Klik Untuk Memulai',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
