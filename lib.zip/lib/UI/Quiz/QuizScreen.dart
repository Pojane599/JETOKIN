import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:jetokin/UI/Quiz/HomeQuiz.dart';
import 'package:jetokin/base_url_provider.dart';
import 'package:provider/provider.dart';
import 'package:audioplayers/audioplayers.dart'; // Tambahkan untuk audio

class QuizScreen extends StatefulWidget {
  final Map<String, dynamic> userData;

  const QuizScreen({Key? key, required this.userData}) : super(key: key);

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  late Future<List<dynamic>> _quizQuestions;
  List<Map<String, dynamic>> _results = [];
  int _currentQuestionIndex = 0;
  int _score = 0;
  int _timeRemaining = 60; // Timer dalam detik
  Timer? _timer;
  bool _isCountdown = true; // Status untuk countdown
  int _countdown = 3; // Countdown dari 3
  String? _feedbackMessage;
  bool _showFeedback = false;

  final AudioPlayer _audioPlayer = AudioPlayer(); // Audio player instance

  // Fungsi untuk mengambil soal kuis
  Future<List<dynamic>> fetchQuizQuestions(String baseUrl) async {
    final uri = Uri.parse('$baseUrl/api/get_quizzes');
    final response = await http.get(uri);

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['quizzes'];
    } else {
      throw Exception('Failed to load quiz questions');
    }
  }

  @override
  void initState() {
    super.initState();
    final baseUrl =
        Provider.of<BaseUrlProvider>(context, listen: false).baseUrl;
    _quizQuestions = fetchQuizQuestions(baseUrl);
    _startCountdown(); // Mulai hitung mundur
  }

  // Fungsi untuk memutar suara
  Future<void> _playCountdownSound() async {
    await _audioPlayer.play(AssetSource('audi/countdown.mp3')); // Path audio
  }

  // Fungsi untuk memutar suara 10 detik terakhir
  Future<void> _playLast10SecondsSound() async {
    await _audioPlayer.play(AssetSource(
        'audio/countdown_last10.mp3')); // Suara khusus untuk 10 detik terakhir
  }

  // Fungsi untuk memulai hitung mundur
  void _startCountdown() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_countdown > 0) {
        _playCountdownSound(); // Mainkan suara hitung mundur
        setState(() {
          _countdown--;
        });
      } else {
        timer.cancel();
        setState(() {
          _isCountdown = false; // Selesai hitung mundur
        });
        _startTimer(); // Mulai timer kuis
      }
    });
  }

  // Fungsi untuk memulai timer kuis
  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timeRemaining > 13) {
        setState(() {
          _timeRemaining--;
        });
      } else if (_timeRemaining <= 13 && _timeRemaining > 0) {
        // Memutar suara khusus ketika tersisa 10 detik
        _playLast10SecondsSound();
        setState(() {
          _timeRemaining--;
        });
      } else {
        timer.cancel();
        _saveQuizResults(); // Simpan hasil jika waktu habis
      }
    });
  }

  // Tambahkan variabel untuk menyimpan hasil jawaban
  void _nextQuestion(bool isCorrect, int quizId, int points) {
    setState(() {
      // Tampilkan feedback
      _feedbackMessage = isCorrect ? 'Benar!' : 'Salah!';
      _showFeedback = true;

      // Simpan hasil ke _results
      _results.add({
        'quiz_id': quizId,
        'score': isCorrect ? points : 0,
      });

      if (isCorrect) {
        _score += points;
      }

      // Delay 1 detik sebelum lanjut ke pertanyaan berikutnya
      Future.delayed(const Duration(seconds: 1), () {
        setState(() {
          _showFeedback = false; // Sembunyikan feedback
          if (_currentQuestionIndex < 9) {
            _currentQuestionIndex++;
          } else {
            _timer?.cancel();
            _saveQuizResults();
          }
        });
      });
    });
  }

  Future<void> _saveQuizResults() async {
    final baseUrl =
        Provider.of<BaseUrlProvider>(context, listen: false).baseUrl;
    final uri = Uri.parse('$baseUrl/api/save_quiz_results');

    try {
      // Debug data sebelum dikirim
      print('Data yang dikirim ke API:');
      print(jsonEncode({
        'user_id': widget.userData['user_id'],
        'results': _results,
      }));

      final response = await http.post(
        uri,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'user_id': widget.userData['user_id'],
          'results': _results, // Gunakan _results
        }),
      );

      if (response.statusCode == 200) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => ResultScreen(
              score: _score,
              userData: widget.userData,
            ),
          ),
        );
      } else {
        // Debug: Cetak respons error
        print('Response status: ${response.statusCode}');
        print('Response body: ${response.body}');
        throw Exception('Failed to save quiz results');
      }
    } catch (e) {
      print('Error during saveQuizResults: $e'); // Debug error
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: const Text('Failed to save quiz results'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel(); // Hentikan timer saat layar ditutup
    _audioPlayer.dispose(); // Bebaskan audio player
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false, // Nonaktifkan tombol kembali
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Quiz'),
              Text(
                _isCountdown
                    ? "Countdown: $_countdown"
                    : "Time: $_timeRemaining sec", // Tampilkan waktu tersisa
                style: const TextStyle(fontSize: 16, color: Colors.white),
              ),
            ],
          ),
          backgroundColor: Colors.redAccent,
        ),
        body: FutureBuilder<List<dynamic>>(
          future: _quizQuestions,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            } else if (snapshot.hasError) {
              return Center(child: Text("Error: ${snapshot.error}"));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text("No quiz questions available"));
            }

            if (_isCountdown) {
              return Center(
                child: Text(
                  "$_countdown",
                  style: const TextStyle(
                    fontSize: 80,
                    fontWeight: FontWeight.bold,
                    color: Colors.redAccent,
                  ),
                ),
              );
            }

            if (_showFeedback) {
              return Center(
                child: Text(
                  _feedbackMessage!,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.green, // Ubah ke merah untuk jawaban salah
                  ),
                ),
              );
            }

            final quizQuestions = snapshot.data!;
            final currentQuestion = quizQuestions[_currentQuestionIndex];

            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Indikator progress
                  LinearProgressIndicator(
                    value:
                        (_currentQuestionIndex + 1) / 10, // Progress dari 0-1
                    backgroundColor: Colors.grey[300],
                    color: Colors.redAccent,
                  ),
                  const SizedBox(
                      height: 10), // Spasi antara indikator dan teks soal
                  Text(
                    "Pertanyaan ${_currentQuestionIndex + 1}/10",
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    currentQuestion['question'],
                    style: const TextStyle(fontSize: 20),
                  ),
                  const SizedBox(height: 20),
                  ...(currentQuestion['options'] as List<dynamic>)
                      .map((option) {
                    return ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.redAccent,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      onPressed: () {
                        _nextQuestion(
                          option ==
                              currentQuestion[
                                  'correct_answer'], // Benar atau salah
                          currentQuestion['quiz_id'], // ID kuis
                          currentQuestion['points'], // Poin dari soal
                        );
                      },
                      child: Text(
                        option,
                        style:
                            const TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    );
                  }).toList(),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final int score;
  final Map<String, dynamic> userData;

  const ResultScreen({Key? key, required this.score, required this.userData})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        color: Colors.redAccent,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Quiz Selesai!',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Skor Anda: $score',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.white.withOpacity(0.7),
                padding:
                    const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Homequiz(
                        userData: userData), // Pastikan userData diteruskan
                  ),
                );
              },
              child: const Text(
                'Kembali ke Beranda',
                style: TextStyle(
                  color: Colors.redAccent,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
